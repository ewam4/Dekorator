﻿using System;
namespace Dekorator
{
    class Program
    {
        static void Main()
        {
            Coffee simpleCoffee = new SimpleCoffee();
            Console.WriteLine($"Koszt: {simpleCoffee.Cost()}PLN; Składniki: {simpleCoffee.Ingredients()}");

            Coffee milkCoffee = new Milk(simpleCoffee);
            Console.WriteLine($"Koszt: {milkCoffee.Cost()}PLN; Składniki: {milkCoffee.Ingredients()}");

            Coffee sugarMilkCoffee = new Sugar(milkCoffee);
            Console.WriteLine($"Koszt: {sugarMilkCoffee.Cost()}PLN; Składniki: {sugarMilkCoffee.Ingredients()}");
        }
    }
}