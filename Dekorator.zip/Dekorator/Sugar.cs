﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dekorator
{
    public class Sugar : CoffeeDecorator
    {
        public Sugar(Coffee coffee) : base(coffee) { }

        public override double Cost()
        {
            return coffee.Cost() + 1; 
        }

        public override string Ingredients()
        {
            return coffee.Ingredients() + ", Sugar"; 
        }
    }
}
