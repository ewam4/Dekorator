﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dekorator
{
    public class Milk : CoffeeDecorator
    {
        public Milk(Coffee coffee) : base(coffee) { }

        public override double Cost()
        {
            return coffee.Cost() + 2; 
        }

        public override string Ingredients()
        {
            return coffee.Ingredients() + ", Milk"; 
        }
    }
}
